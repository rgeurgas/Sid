#ifdef __linux__
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <GL/glut.h>
#elif __APPLE__
    #include <OpenGL/gl.h>
    #include <OpenGL/glu.h>
    #include <GLUT/glut.h>
#endif

#include <math.h>

// Variaveis locais para transformações de rotação.
double angle = 0;
double increment = 1;

void init() {
    glClearColor(0, 0, 0, 0);
}

// Função para capturar os eventos do teclado
void keyPressEvent(unsigned char key, int x, int y) {
    switch(key) {
        case '\x1b' :
            // Sai do programa se apertar ESC
            exit(0);
            break;
        case '.' :
            // Aumenta o passo do incremento
            increment++;
            break;
        case ',' :
            // Diminui o passo do incremento
            increment--;
            break;
    }
    
}


void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glLoadIdentity();

    glTranslatef(0.5*cos(angle*3.14/180), 0.3*sin(angle*3.14/180), 0);

    glRotatef(angle, 0, 0, 1);
    glScalef(0.1, 0.1, 0);
    glBegin(GL_TRIANGLES);
    glColor3f(1,0,0);
    glVertex3f(0,0,0);
    glColor3f(1,1,0);
    glVertex3f(1,0,0);
    glColor3f(1,0,1);
    glVertex3f(0,1,0);
    glEnd();

    glFlush();
}


// Função utizada na função de callback temporizada
void timer(int value) {
    angle += increment;
    
    // Chama a função para desenhar a tela após a mudança
    display();

    // Define a função timer na função de callback temporizada
    glutTimerFunc(30, timer, 0);
}



int main(int argc, char *argv[]) {
    glutInit(&argc, argv);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Hello World!");
    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyPressEvent);
    timer(0);

    glutMainLoop();
}
