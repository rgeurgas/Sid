#ifdef __linux__
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <GL/glut.h>
#elif __APPLE__
    #include <OpenGL/gl.h>
    #include <OpenGL/glu.h>
    #include <GLUT/glut.h>
#endif

#include <math.h>

// Variaveis globais para transformações de rotação.
double curAngle = 0;
double increment = 1;

// Variáveis auxiliares
int toggleAnimation = 1;
int curObject = 0;
int curShading = 0;
char lightTypes[4][2][100] = {{"Diffuse reflection only","No ambient or specular"},
            {"Diffuse and specular reflection", "Low shininess; no ambient"},
            {"Diffuse and specular reflection", "high shininess; no ambient"},
            {"Diffuse refl.; emission", "no ambient or specular reflection"}};


// Função utilizada para desenhar uma string na tela
void glut_print(double x, double y, void *font, char *text, double r, double g , double b , double a) {
    int blending = 0;
    if(glIsEnabled(GL_BLEND)) {
        blending = 1;
    }

    //glEnable(GL_BLEND)
    glColor3f(1,1,1);
    glRasterPos2f(x,y);
    for(int i=0; text[i]!='\0'; i++){
        glutBitmapCharacter( font , text[i] );
    }
    if(!blending) {
        glDisable(GL_BLEND);
    }
}



void init() {
    // Agora temos que cuidar também o buffer de profundidade.
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH) ;
    // Define as dimensoes da janela.
    glutInitWindowSize(800, 800);
    // Define posicao inicial da janela na tela
    glutInitWindowPosition(100, -500);
    glutCreateWindow("Hello World!");
    // Pedimos para o OpenGL verificar o buffer de profundidade na hora de renderizar. Precisa ser depois de criada a janela!
    glEnable(GL_DEPTH_TEST);

    glClearColor(0, 0, 1, 0);
}

// Inicializa a luz
void initLighting() {
    // Informa que irá utilizar iluminação    
    glEnable(GL_LIGHTING);
    // Liga a luz0
    glEnable(GL_LIGHT0);
    // Informa que irá utilizar as cores do material
    glEnable(GL_COLOR_MATERIAL);
}

// Define a posição da luz 0
void setLight() {
    GLfloat light_position[4] = {10.0, 10.0, -20.0, 0.0};
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
}

// Função utilizada para definir as propriedades do material
void setMaterial(int currentMaterial){
    GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat mat_ambient[] = { 0.7, 0.7, 0.7, 1.0 };
    GLfloat mat_ambient_color[] = { 0.8, 0.8, 0.2, 1.0 };
    GLfloat mat_diffuse[] = { 0.1, 0.5, 0.8, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat no_shininess[] = { 0.0 };
    GLfloat low_shininess[] = { 5.0 };
    GLfloat high_shininess[] = { 100.0 };
    GLfloat mat_emission[] = {0.3, 0.2, 0.2, 0.0};

    switch (currentMaterial){
    case 0:
        // Diffuse reflection only; no ambient or specular  
        glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
        glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
        break;
        
    case 1:
        // Diffuse and specular reflection; low shininess; no ambient
        glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
        glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
        break;
        
    case 2:
        // Diffuse and specular reflection; high shininess; no ambient
        glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
        glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
        break;
        
    case 3:
        // Diffuse refl.; emission; no ambient or specular reflection
        glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
        glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
        break;
    }     
}


// Função para capturar os eventos do teclado
void keyPressEvent(unsigned char key, int x, int y) {
    switch(key) { 
        case '\x1b' :
         // Sai do programa se apertar ESC
            exit(0);
            break;
        case '.' :
            // Aumenta o passo do incremento
            increment += 1;
            break;
        case ',' :
            // Diminui o passo do incremento
            increment += -1;
            break;
        case 'a' :
            // Liga ou desliga a animação
            toggleAnimation = !toggleAnimation;
            break;
        case 'q' :
            // Troca o objeto mostrado
            curObject += 1;
            curObject %= 4;
            break;
        case 's' :
            curShading += 1;
            curShading %= 2;
            break;
    }
}

// Função para definir o tipo de tonalização
void setShading(int sType) {
    switch(sType) { 
        case 0 :
            glShadeModel(GL_SMOOTH);
            break;            
        case 1 :
            glShadeModel(GL_FLAT);
            break;
    }
}

void drawObject(int oType, int currentMaterial) {
    setMaterial(currentMaterial);

    glColor3f(1,1,0);
    switch(oType) {
        case 0:
            glutWireCube(1);
            break;
        case 1 :
            glutSolidCube(1);
            break;
        case 2 :
            glutSolidSphere(1, 100, 100);
            break;
        case 3 :
            glutSolidTeapot(1);
            break;
    }
}

// Função para desenhar a descrição de cada configuração de iluminação
void drawDescriptionText(int currentMaterial) {
    glDisable(GL_LIGHTING);
    double pos = 1.2;
    for(int i = 0; i < 2; i++){
        glut_print( -1.9 , pos , GLUT_BITMAP_9_BY_15 , lightTypes[currentMaterial][i], 1.0 , 1.0 , 1.0 , 1.0 );
        pos -= 0.2;
    }
    glEnable(GL_LIGHTING);
}    


void display(){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Define a matriz de projeção ortogonal
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-2, 2, -2, 2, -2, 100);
    

    // Define que irá trabalhar com a matriz de modelo/visão
    glMatrixMode(GL_MODELVIEW);
    setLight();
    setShading(curShading);
    
    // Para cada porta de visão, configura as propriedades do material e desenha o objeto
    glViewport(0,0,400,400);
    glLoadIdentity();
    drawDescriptionText(0);
    glRotatef(curAngle, 1, 1, 1);
    drawObject(curObject, 0);


    glViewport(400,0,400,400);
    glLoadIdentity();
    drawDescriptionText(1);
    glRotatef(curAngle, 1, 1, 1);
    drawObject(curObject, 1);


    glViewport(0, 400 ,400,400);
    glLoadIdentity();
    drawDescriptionText(2);
    glRotatef(curAngle, 1, 1, 1);
    drawObject(curObject, 2);


    glViewport(400,400,400,400);
    glLoadIdentity();
    drawDescriptionText(3);
    glRotatef(curAngle, 1, 1, 1);
    drawObject(curObject, 3);

    glFlush();
}


// Função utizada na função de callback temporizada
void timer(int value) {
    curAngle += increment;
    
    // Chama a função para desenhar a tela após a mudança
    display();

    // Define a função timer na função de callback temporizada
    glutTimerFunc(30, timer, 0);
}


int main(int argc, char *argv[]){
  
    glutInit(&argc, argv);
    
    init();
    initLighting();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyPressEvent);
    timer(0);
    
    glutMainLoop();
}
