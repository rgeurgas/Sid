#ifdef __linux__
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <GL/glut.h>
#elif __APPLE__
    #include <OpenGL/gl.h>
    #include <OpenGL/glu.h>
    #include <GLUT/glut.h>
#endif

#include <math.h>


// Variaveis locais para transformações de rotação.
double angle = 0;
double increment = 1;
int toggleAnimation = 1;

void init() {
    glClearColor(0, 0, 0, 0);
}
    
// Função para capturar os eventos do teclado
void keyPressEvent(unsigned char key, int x, int y) {
 
    switch(key) {
        case '\x1b' :
         // Sai do programa se apertar ESC
        exit(0);
        break;
        case '.' :
        // Aumenta o passo do incremento
        increment += 1;
        break;
        case ',' :
        // Diminui o passo do incremento
        increment += -1;
        break;
        case 'a' :
        // Liga ou desliga a animação
        toggleAnimation = !toggleAnimation;
        break;
    }
}




// Configura o tipo de projeção que será utilizada
void switchProjection(int pType) {
    // Define que irá trabalhar com a matriz de projeção
    glMatrixMode(GL_PROJECTION);
    // Carrega a matriz identidade
    glLoadIdentity();
    
    switch(pType) { 
        case 0 :
            // Projeção ortogonal, deve-se informar o tamanho da janela de projeção:
            // x_min, x_max, y_min, y_max, z_min, z_max 
            glOrtho(-1, 1, -1, 1, -10, 10);
            break;
        case  1 :
            // Projeção em perspectiva (OpenGL), deve-se informar o tamanho da janela de projeção:
            // x_min, x_max, y_min, y_max, z_near, z_far
            glFrustum(-1, 1, -1, 1, 1, 100);
            break;
        case  2 :
            // Projeção em perspectiva (GLU), deve-se informar o tamanho da janela de projeção:
            // angulo de visão, aspecto (w/h), z_near, z_far
            gluPerspective(45, 1, 1, 100);
            break;

    }
}

// Desenha os eixos x, y e z
void drawAxis() {
    glBegin(GL_LINES);
    glColor3f(1, 0, 0);
    glVertex3f(0,0,0);
    glColor3f(1, 1, 1);
    glVertex3f(1,0,0);
    glEnd();
    
    glColor3f(0, 1, 0);
    glBegin(GL_LINES);
    glVertex3f(0,0,0);
    glColor3f(1, 1, 1);
    glVertex3f(0,1,0);
    glEnd();

    glColor3f(0, 0, 1);
    glBegin(GL_LINES);
    glVertex3f(0,0,0);
    glColor3f(1, 1, 1);
    glVertex3f(0,0,1);
    glEnd();
}


void display(){
    glClear(GL_COLOR_BUFFER_BIT);

    // Define uma porta de visão para a projeção ortogonal
    glViewport(0, 0, 400, 400);
    
    // Chama a função para configurar o tipo de projeção ortogonal
    switchProjection(0);
    
    // Define que irá trabalhar com a matriz de modelo/visão
    glMatrixMode(GL_MODELVIEW);
    // Carrega a matriz identidade
    glLoadIdentity();
    // Define as configurações do observador
    gluLookAt(0, 0, 2, 0, 0, 0, 0, 1, 0);
    // Rotaciona o objeto
    glRotatef(angle, 1, 1, 1);
    
    // Desenha o eixo
    drawAxis();

    // Desenha o cubo em arame na cor branca
    glColor3f(1,1,1);
    glutWireCube(0.5);

    // Define uma porta de visão para a projeção em perspectiva
    glViewport(400, 0, 400, 400);

    // Chama a função para configurar o tipo de projeção
    switchProjection(2);
    
    // Define que irá trabalhar com a matriz de modelo/visão
    glMatrixMode(GL_MODELVIEW);
    // Carrega a matriz identidade
    glLoadIdentity();
    // Define as configurações do observador
    gluLookAt(0, 0, 2, 0, 0, 0, 0, 1, 0);
    // Rotaciona o objeto
    glRotatef(angle, 1, 1, 1);
    
    // Desenha o eixo
    drawAxis();

    // Desenha o cubo em arame na cor branca
    glColor3f(1,1,1);
    glutWireCube(0.5);


    glFlush();
}

// Função utizada na função de callback temporizada
void timer(int value) {
    // Apenas realiza as operações de animação se estiver ligado
    if(toggleAnimation){
        angle += increment;
        
        // Chama a função para desenhar a tela após a mudança
        display();
    }
    // Define a função timer na função de callback temporizada
    glutTimerFunc(30, timer, 0);
}

int main(int argc, char *argv[]) {
    glutInit(&argc, argv);
    glutInitWindowSize(800, 400);
    glutCreateWindow("Hello World!");
    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyPressEvent);
    timer(0);

    glutMainLoop();
}
