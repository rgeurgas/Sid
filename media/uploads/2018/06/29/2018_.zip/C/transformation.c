#ifdef __linux__
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <GL/glut.h>
#elif __APPLE__
    #include <OpenGL/gl.h>
    #include <OpenGL/glu.h>
    #include <GLUT/glut.h>
#endif


void init() {
    glClearColor(0, 0, 1, 0);
}

// Função utilizada para desenhar a cena
// Evitar realizar cálculos nessa função
void display(){
    glClear(GL_COLOR_BUFFER_BIT);

    // Define que ira trabalhar com a matriz de modelo/visão
    glMatrixMode(GL_MODELVIEW);

    // Carrega a matriz identidade
    glLoadIdentity();

    // As transformações são realizadas de baixo para cima.
    glRotatef(45, 0, 0, 1);
    glScalef(0.5, 0.5, 0);
    glTranslatef(-0.5, -0.5, 0);

    glBegin(GL_TRIANGLES);
    glColor3f(1,0,0);
    glVertex3f(0,0,0);
    glColor3f(1,1,0);
    glVertex3f(1,0,0);
    glColor3f(1,0,1);
    glVertex3f(0,1,0);
    glEnd();

    glFlush();

}


int main(int argc, char *argv[]) {
    glutInit(&argc, argv);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Hello World!");

    init();

    glutDisplayFunc(display);
    
    glutMainLoop();
}