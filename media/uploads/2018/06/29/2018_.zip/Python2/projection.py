# -*- coding: utf-8 -*-

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

import math

# Variaveis globais para transformações de rotação.
angle = 0
increment = 1
toggleAnimation = True

def init() :
    glClearColor(0, 0, 0, 0)
    
# Função para capturar os eventos do teclado
def keyPressEvent(key, x, y) :
    global increment, toggleAnimation
    if key == '\x1b' :
         # Sai do programa se apertar ESC
        exit(0)
    elif key == '.' :
        # Aumenta o passo do incremento
        increment += 1
    elif key == ',' :
        # Diminui o passo do incremento
        increment += -1
    elif key == 'a' :
        # Liga ou desliga a animação
        toggleAnimation = not toggleAnimation

# Função utizada na função de callback temporizada
def timer(value) :
    # Apenas realiza as operações de animação se estiver ligado
    if toggleAnimation == True :
        global angle
        angle += increment
        
        # Chama a função para desenhar a tela após a mudança
        display()
    
    # Define a função timer na função de callback temporizada
    glutTimerFunc(30, timer, 0)


# Configura o tipo de projeção que será utilizada
def switchProjection(pType) :
    # Define que irá trabalhar com a matriz de projeção
    glMatrixMode(GL_PROJECTION)
    # Carrega a matriz identidade
    glLoadIdentity()
    
    if pType == 0 :
        # Projeção ortogonal, deve-se informar o tamanho da janela de projeção:
        # x_min, x_max, y_min, y_max, z_min, z_max 
        glOrtho(-1, 1, -1, 1, -10, 10)
    elif pType == 1 :
        # Projeção em perspectiva (OpenGL), deve-se informar o tamanho da janela de projeção:
        # x_min, x_max, y_min, y_max, z_near, z_far
        glFrustum(-1, 1, -1, 1, 1, 100)
    elif pType == 2 :
        # Projeção em perspectiva (GLU), deve-se informar o tamanho da janela de projeção:
        # angulo de visão, aspecto (w/h), z_near, z_far
        gluPerspective(45, 1, 1, 100)

# Desenha os eixos x, y e z
def drawAxis() :
    glBegin(GL_LINES)
    glColor3f(1, 0, 0)
    glVertex3f(0,0,0)
    glColor3f(1, 1, 1)
    glVertex3f(1,0,0)
    glEnd()
    
    glColor3f(0, 1, 0)
    glBegin(GL_LINES)
    glVertex3f(0,0,0)
    glColor3f(1, 1, 1)
    glVertex3f(0,1,0)
    glEnd()

    glColor3f(0, 0, 1)
    glBegin(GL_LINES)
    glVertex3f(0,0,0)
    glColor3f(1, 1, 1)
    glVertex3f(0,0,1)
    glEnd()
    


def display():
    glClear(GL_COLOR_BUFFER_BIT)

    # Define uma porta de visão para a projeção ortogonal
    glViewport(0, 0, 400, 400)
    
    # Chama a função para configurar o tipo de projeção ortogonal
    switchProjection(0)
    
    # Define que irá trabalhar com a matriz de modelo/visão
    glMatrixMode(GL_MODELVIEW)
    # Carrega a matriz identidade
    glLoadIdentity()
    # Define as configurações do observador
    gluLookAt(0, 0, 2, 0, 0, 0, 0, 1, 0)
    # Rotaciona o objeto
    glRotatef(angle, 1, 1, 1)
    
    # Desenha o eixo
    drawAxis()

    # Desenha o cubo em arame na cor branca
    glColor3f(1,1,1)
    glutWireCube(0.5)

    # Define uma porta de visão para a projeção em perspectiva
    glViewport(400, 0, 400, 400)

    # Chama a função para configurar o tipo de projeção
    switchProjection(2)
    
    # Define que irá trabalhar com a matriz de modelo/visão
    glMatrixMode(GL_MODELVIEW)
    # Carrega a matriz identidade
    glLoadIdentity()
    # Define as configurações do observador
    gluLookAt(0, 0, 2, 0, 0, 0, 0, 1, 0)
    # Rotaciona o objeto
    glRotatef(angle, 1, 1, 1)
    
    # Desenha o eixo
    drawAxis()

    # Desenha o cubo em arame na cor branca
    glColor3f(1,1,1)
    glutWireCube(0.5)


    glFlush()




if __name__ == '__main__':
    
    glutInit()
    glutInitWindowSize(800, 400)
    glutCreateWindow("Hello World!")
    init()

    glutDisplayFunc(display)
    glutKeyboardFunc(keyPressEvent)
    timer(0)

    glutMainLoop()